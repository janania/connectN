#ifndef SETUP_H
  #define SETUP_H
	
    int who_goes_first();
    char which_piece(int* player);
    char** setup_game(int r, int c, int num_needed, int* player);

#endif